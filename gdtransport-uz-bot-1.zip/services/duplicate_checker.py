# duplicate checker
